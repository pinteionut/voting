import React from 'react'

export const Register: React.FC = () => {
    return (
      <>{'Register component...'}</>
    )
  }
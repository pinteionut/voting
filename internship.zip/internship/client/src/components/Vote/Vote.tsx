import React from 'react';

export const Vote: React.FC = () => {
  return (
    <>{'Vote component...'}</>
  )
}
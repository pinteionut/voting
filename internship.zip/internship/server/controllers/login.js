export const doLogin = (req, res, next) => {
  const username = req.body.username;
  const password = req.body.password;

  console.log(req)

  if (username === 'username' && password === 'password') {
    res.send(true)
  }

  res.send(false)
}

export const doLogout = (req, res, next) => {
  const username = req.body.username;
  const password = req.body.password;

  console.log(req)

  if (username === 'username' && password === 'password') {
    res.send(true)
  }

  res.send(false)
}
import express from 'express'
import cors from 'cors'
import bodyParser from 'body-parser';

import { router as loginRoutes } from './routes/login.js'

const app = express();

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(cors());
app.use('/login', loginRoutes);

app.listen(3000)